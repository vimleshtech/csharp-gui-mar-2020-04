﻿using System;
using System.Dynamic;

namespace ConsoleAppOOPs
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");


            /*
            //create array of object
            Student[] sObject = new Student[5];//size of object (array)

            //take input
            for(int i = 0; i < sObject.Length; i++)
            {
                //allocate the memory for every every object 
                sObject[i] = new Student(); //invoke to constructor and allocate the memory
                sObject[i].input(); //invoke to input function and store the data 
            }

            //print all data 
            Console.WriteLine("------Unsorted data /print in same order ------");
            foreach(Student s in sObject)
            {
                s.show();
            }

            //sort the data by rno
            for(int i=0; i < sObject.Length; i++)
            {
                for(int j=i+1; j < sObject.Length; j++)
                {
                    if(sObject[i].getRollNo() > sObject[j].getRollNo())
                    {
                        Student temp = sObject[i];
                        sObject[i] = sObject[j];
                        sObject[j] = temp;
                    }

                }
            }
            Console.WriteLine("------Sorted data /print in same order ------");
            foreach (Student s in sObject)
            {
                s.show();
            }
            //find student by rno 
            int rno_to;
            Console.WriteLine("enter rno to find ");
            rno_to = Convert.ToInt32(Console.ReadLine());
            for(int i=0; i<sObject.Length;i++)
            {
                if(sObject[i].getRollNo() == rno_to)
                    sObject[i].show();
            }
            */



            //Constructor example
            Employee e = new Employee();
            e.show();

            //create new object with argument 
            Employee e2 = new Employee("us");
            e2.show();


            Console.ReadLine();



        }
    }
}
