﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppOOPs
{
   public class Student
    {
        private int rno;
        private string name;
        private string address;
        private string city;
        private string country;

        public void input()
        {
            Console.WriteLine("enter rno, name, address, city ,and country");
            this.rno = Convert.ToInt32(Console.ReadLine());
            this.name = Console.ReadLine();
            this.address = Console.ReadLine();
            this.city = Console.ReadLine();
            this.country = Console.ReadLine();

        }
        public int getRollNo()
        {
            return rno;
        }
        public void show()
        {
            Console.WriteLine("-----Student Details------");
            Console.WriteLine("RNo is  " + this.rno);
            Console.WriteLine("Name is  " + this.name);
            Console.WriteLine("City is  " + this.city);
            Console.WriteLine("Country is  " + this.country);
            Console.WriteLine("Address is  " + this.address);

        }
        
    }
}
