﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppOOPs
{
    public class Employee
    {

        private int eid;
        private string name;
        private string city;
        private string country;
        private int basic_sal;

        //default or without parameter constructor 
        public Employee()
        {
            Console.WriteLine("Object is created , constructos is invoked automatically");
            this.eid = 0;
            this.name = "Guest User";
            this.city = "";
            this.country = "";
            this.basic_sal = 0;
        
        }


        //with parameter constructoer
        public Employee(string country)
        {
            Console.WriteLine("Object is created , constructos is invoked automatically");
            if (country.ToUpper().Equals("INDIA"))
            {
                this.eid = 0;
                this.name = "Guest User";
                this.city = "";
                this.country = "";
                this.basic_sal = 0;

            }
            else
            {
                this.eid = 0;
                this.name = "NewUser";
                this.city = "";
                this.country = "";
                this.basic_sal = 0;

            }
        }


        public void show()
        {

            Console.WriteLine("----------Employee Details ------------");
            Console.WriteLine("eid " + this.eid);
            Console.WriteLine("name " + this.name);
            Console.WriteLine("country " + this.country);
            Console.WriteLine("city " + this.city);
            Console.WriteLine("salary " + this.basic_sal);

        }


    }
}
