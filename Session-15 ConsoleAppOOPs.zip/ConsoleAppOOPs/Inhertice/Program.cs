﻿using System;

namespace Inhertice
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            DCal d = new DCal();
            d.add(44, 55);
            d.sub(44, 6);
            double o = d.income_tax(5556666);

            Console.WriteLine(o);

            Console.Read();

        }
    }
}
