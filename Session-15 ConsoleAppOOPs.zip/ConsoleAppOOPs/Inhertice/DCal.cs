﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inhertice
{
    public  class DCal: Cal //inheritence 
    {

        public double gst(int amt)
        {
            double tax = 0;
            if (amt > 1000)
            {
                tax = amt * .18;
            }else if (amt > 500)
            {
                tax = amt * .10;
            }
            else {
                tax = amt * .05;
            }
            return tax;
        }
        public double income_tax(int salary)
        {
            double tax;
            if (salary < 250000)
            {
                tax = 0;
            }
            else if (salary < 500000)
            {

                tax = salary * .05;
            }
            else if (salary < 1000000)
            {

                tax = salary * .20;
            }
            else
            {
                tax = salary * .30;
            }
            return tax; 
        }
    }
}
