﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Polymorphsiam
{
   public class DCalc: Calc
    {
        public void add(int a, int b, int c)
        {
            Console.WriteLine("sum of three values " + (a + b + c));

        }
        public void add(double a, double b)
        {
            Console.WriteLine("sum of two doble values " + (a + b));
        }

        //overriding 
        public void add(int a, int b)
        {
            Console.WriteLine("sum of two values in child class " + (a + b ));

        }

    }
}
