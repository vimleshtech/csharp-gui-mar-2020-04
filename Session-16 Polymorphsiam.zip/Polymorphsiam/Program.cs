﻿using System;

namespace Polymorphsiam
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //create an object of child class


            //overloading 
            DCalc o = new DCalc();
            o.add(11, 44);
            o.add(4, 666, 777);
            o.sub(55, 66);
            o.add(5556.44, 666.33);



            ///create object of parent class 
            ///
            Calc c = new Calc();
            c.add(11, 44);//call parent class function 

            //create object of child class 
            DCalc dd = new DCalc();
            dd.add(11, 44);//call child class function 

            //overwrite the memory 
            c = dd;
            c.add(55, 6); //call child class function 

            //or
            Calc xx = new DCalc();
            xx.add(54, 66);

            
        }
    }
}
