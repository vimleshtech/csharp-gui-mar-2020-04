﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Polymorphsiam
{
   public class Calc
    {

        //will be overwriten
        public virtual void add(int a, int b)
        {

            Console.WriteLine(a + b);
        }

        public void sub(int a, int b)
        {

            Console.WriteLine(a - b);
        }

    }
}
