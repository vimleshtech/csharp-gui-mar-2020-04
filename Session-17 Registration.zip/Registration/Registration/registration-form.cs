﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class registration_form : Form
    {
        public registration_form()
        {
            InitializeComponent();

            ///
        }

        private void registration_form_Load(object sender, EventArgs e)
        {

            //bind data on form load
            ddlCountry.Items.Add("India");
            ddlCountry.Items.Add("US");
            ddlCountry.Items.Add("UK");
            ddlCountry.Items.Add("Australlia");

            //
            ddlCitySelection.Items.Add("Delhi");
            ddlCitySelection.Items.Add("Pune");
            ddlCitySelection.Items.Add("Hyderabad");
            ddlCitySelection.Items.Add("Noida");
            ddlCitySelection.Items.Add("Gurugram");

            //
            ddlState.Items.Add("Test1");
            ddlState.Items.Add("Test2");
            ddlState.Items.Add("Test3");
            ddlState.Items.Add("Test4");
            ddlState.Items.Add("Test5");
            ddlState.Items.Add("Test6");



        }

        private void Clear_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
